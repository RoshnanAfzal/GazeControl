# *********************** GAZE CONTROLLED DESKTOP **************************

# *********************** MAHNOOR FATIMA **************************
# *********************** SAWERA EHSAN **************************
# *********************** SAIF UR REHMAN **************************

# *********************** FYP NUML **************************

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QPainter, QPen
import cv2
import dlib
from math import hypot
import pyglet
from imutils import face_utils
from utils import *
import pyautogui as pag
import imutils
import subprocess
import sys
from pynput.keyboard import Key, Controller
import time
# import screen_brightness_control as sbc
import os

keyboard = Controller()


class Ui_MainWindow(object):

    def setupUi(self, MainWindow):
        MainWindow.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        MainWindow.setAttribute(QtCore.Qt.WA_NoSystemBackground, True)
        MainWindow.setAttribute(QtCore.Qt.WA_TranslucentBackground, True)
        MainWindow.setObjectName("MainWindow")
        MainWindow.setGeometry(400, 50, 577, 132)
        MainWindow.setWindowOpacity(1.0)
        MainWindow.setStyleSheet("")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget, clicked=lambda: self.keyboardcontrol())
        self.pushButton.setGeometry(QtCore.QRect(80, 50, 81, 41))
        self.pushButton.setStyleSheet(open("stylesheet.css").read())
        self.pushButton.setText("")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("keyboard1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton.setIcon(icon)
        self.pushButton.setIconSize(QtCore.QSize(111, 41))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget, clicked=lambda: self.brightness_increase())
        self.pushButton_2.setGeometry(QtCore.QRect(160, 50, 81, 41))
        self.pushButton_2.setStyleSheet(open("stylesheet.css").read())
        self.pushButton_2.setText("")
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap("brightness1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton_2.setIcon(icon2)
        self.pushButton_2.setIconSize(QtCore.QSize(111, 41))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget, clicked=lambda: self.brightness_decrease())
        self.pushButton_3.setGeometry(QtCore.QRect(240, 50, 81, 41))
        self.pushButton_3.setStyleSheet(open("stylesheet.css").read())
        self.pushButton_3.setText("")
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap("brightness2.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton_3.setIcon(icon3)
        self.pushButton_3.setIconSize(QtCore.QSize(111, 41))
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_4 = QtWidgets.QPushButton(self.centralwidget, clicked=lambda: quit())
        self.pushButton_4.setGeometry(QtCore.QRect(410, 20, 31, 21))
        self.pushButton_4.setStyleSheet(open("stylesheet.css").read())
        self.pushButton_4.setText("")
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap("close.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton_4.setIcon(icon4)
        self.pushButton_4.setObjectName("pushButton_4")
        self.pushButton_5 = QtWidgets.QPushButton(self.centralwidget, clicked=lambda: self.volume_increase())
        self.pushButton_5.setGeometry(QtCore.QRect(320, 50, 71, 41))
        self.pushButton_5.setStyleSheet(open("stylesheet.css").read())
        self.pushButton_5.setText("")
        icon5 = QtGui.QIcon()
        icon5.addPixmap(QtGui.QPixmap("sound1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton_5.setIcon(icon5)
        self.pushButton_5.setIconSize(QtCore.QSize(111, 35))
        self.pushButton_5.setObjectName("pushButton_5")
        self.pushButton_6 = QtWidgets.QPushButton(self.centralwidget, clicked=lambda: self.volume_decrease())
        self.pushButton_6.setGeometry(QtCore.QRect(390, 50, 61, 41))
        self.pushButton_6.setStyleSheet(open("stylesheet.css").read())
        self.pushButton_6.setText("")
        icon6 = QtGui.QIcon()
        icon6.addPixmap(QtGui.QPixmap("sound2.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton_6.setIcon(icon6)
        self.pushButton_6.setIconSize(QtCore.QSize(111, 35))
        self.pushButton_6.setObjectName("pushButton_6")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def volume_increase(self):
        keyboard.press(Key.media_volume_up)

    def volume_decrease(self):
        keyboard.press(Key.media_volume_down)

    def brightness_increase(self):
        # sbc.set_brightness('+25')
        print("Brightness increase 25%")

    def brightness_decrease(self):
        # sbc.set_brightness('-25')
        print("Brightness decrease 25%")

    def keyboardcontrol(self):
        subprocess.Popen(['python', 'keyboardcontrol.py'])
        sys.exit()

    def mousecontrol(self):
        exec(open("mousecursorcontrol.py").read())

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))


if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    ui.mousecontrol()
    sys.exit(app.exec_())
